---
name: Sunset Sky Narrative
colors:
  surface: '#f6faff'
  surface-dim: '#d0dbe7'
  surface-bright: '#f6faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ebf5ff'
  surface-container: '#e4effb'
  surface-container-high: '#deeaf5'
  surface-container-highest: '#d8e4ef'
  on-surface: '#121d25'
  on-surface-variant: '#42474c'
  inverse-surface: '#27323a'
  inverse-on-surface: '#e7f2fe'
  outline: '#73787c'
  outline-variant: '#c2c7cc'
  surface-tint: '#476273'
  primary: '#476273'
  on-primary: '#ffffff'
  primary-container: '#bad6ea'
  on-primary-container: '#435d6e'
  inverse-primary: '#aecade'
  secondary: '#65587c'
  on-secondary: '#ffffff'
  secondary-container: '#e3d3fd'
  on-secondary-container: '#66597d'
  tertiary: '#6d5866'
  on-tertiary: '#ffffff'
  tertiary-container: '#e5cbdb'
  on-tertiary-container: '#685461'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cae6fb'
  primary-fixed-dim: '#aecade'
  on-primary-fixed: '#001e2d'
  on-primary-fixed-variant: '#2f4a5a'
  secondary-fixed: '#ebddff'
  secondary-fixed-dim: '#cfc0e9'
  on-secondary-fixed: '#201635'
  on-secondary-fixed-variant: '#4d4163'
  tertiary-fixed: '#f6dbeb'
  tertiary-fixed-dim: '#d9bfcf'
  on-tertiary-fixed: '#261722'
  on-tertiary-fixed-variant: '#54414e'
  background: '#f6faff'
  on-background: '#121d25'
  surface-variant: '#d8e4ef'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  sidebar-width: 280px
  gutter: 16px
  container-padding: 24px
---

## Brand & Style

The design system is built for a desktop messaging experience that balances professional utility with a high-end, "cute" aesthetic. The brand personality is optimistic, calm, and approachable, aimed at users who value a serene workspace.

The visual style is a hybrid of **Modern Corporate** and **Soft Minimalism**. It utilizes an airy, white-dominant interface to reduce cognitive load, while employing soft pastel gradients and rounded geometry to maintain a friendly, approachable character. The "cute" elements are expressed through micro-interactions, subtle heart motifs (inspired by the logo), and a palette that evokes a clear morning sky. High-quality SaaS execution is ensured through rigorous alignment, generous whitespace, and refined typography.

## Colors

The palette is derived from a "Sunset Sky" concept. The primary color is a soft Sky Blue, used for high-frequency actions and active states. Secondary and Tertiary accents (Light Violet and Soft Pink) are reserved for decorative highlights and brand-specific flourishes.

**AI Identity:** 
A specific "AI Hue" is created by blending Soft Lavender and Pale Rose. Any interface elements driven by artificial intelligence—such as smart replies, summaries, or the assistant bot—must use these specific gradients to differentiate them from standard user-to-user communication.

**Color Application:**
- **Primary Text:** Use "Night" (#111C24) for high readability.
- **Secondary/Meta Text:** Use "Dusty Blue" (#7A9BB5) for timestamps and muted labels.
- **Surface:** Predominantly White (#FFFFFF) with Ice Blue (#F3F8FC) used for sidebars or search fields to create subtle depth.

## Typography

The typography strategy uses **Hanken Grotesk** for headings to provide a sharp, contemporary "tech" feel, while **Plus Jakarta Sans** is used for body and interface labels due to its soft terminals and superior legibility in chat bubbles.

Line heights are intentionally generous to support the "airy" feel of the system. For chat messages, `body-md` is the standard. Use `label-sm` for timestamps and read receipts. Display styles should be used sparingly for empty states or onboarding screens.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model optimized for desktop. 
- **Sidebar:** Fixed 280px width, containing the conversation list.
- **Main Content:** Fluid messaging area that expands to fill the viewport.
- **Gutter:** A consistent 16px gutter exists between the conversation list and the active chat panel.

Spacing is based on a 4px baseline grid. Internal padding for chat bubbles should be 12px (vertical) and 16px (horizontal) to maintain the airy aesthetic. Generous margins (24px) are used around the main window container to give the UI room to "breathe" against the desktop wallpaper.

## Elevation & Depth

This design system uses **Tonal Layering** combined with **Ambient Shadows**. 

1. **Surface 0 (Background):** White (#FFFFFF) or Night (#111C24) in dark mode.
2. **Surface 1 (Inset):** Ice Blue (#F3F8FC) for sidebars and search bars, using a subtle 1px border (#DDECF6) instead of a shadow.
3. **Surface 2 (Elevated):** White chat bubbles or Modals. These use a very soft, diffused shadow: `0px 4px 20px rgba(122, 155, 181, 0.1)`. 

The goal is to avoid heavy blacks in shadows; instead, shadows should be tinted with "Dusty Blue" to maintain the sky-like atmosphere.

## Shapes

The shape language is defined by "Moderate Softness." 
- **Standard UI Elements:** (Buttons, Input Fields) use a 0.5rem (8px) radius.
- **Chat Bubbles:** Use a 1rem (16px) radius, with the corner directed toward the sender slightly sharper (4px) to indicate directionality.
- **Avatars:** Strictly circular to contrast against the soft-square geometry of the rest of the interface.

## Components

### Buttons
- **Primary:** Sky Blue (#BAD6EA) background with Night (#111C24) text. No heavy borders.
- **Secondary:** Transparent background with a 1px Soft Sky (#DDECF6) border.
- **AI Action:** A subtle gradient from Soft Lavender to Pale Rose.

### Input Fields
Inputs are borderless with a Soft Sky (#DDECF6) background. On focus, the background remains, but a 2px Sky Blue (#BAD6EA) bottom border appears.

### Chat Bubbles
- **Sender (User):** White background with a soft ambient shadow.
- **Recipient:** Ice Blue (#F3F8FC) background, no shadow.
- **AI Response:** A very thin 1px gradient border (Lavender/Pink) with a faint tint background.

### Chips & Badges
Used for status (Online/Away) or tags. These should have a pill-shaped radius (3) and use highly desaturated versions of the accent colors to avoid visual noise.

### Scrollbars
Thin, rounded tracks using "Dusty Blue" at 20% opacity, becoming 40% on hover. Avoid standard OS scrollbars to maintain the "polished SaaS" look.